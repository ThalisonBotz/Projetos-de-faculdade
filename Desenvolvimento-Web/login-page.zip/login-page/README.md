Atividade proposta para a criação de uma pagina de login simples usando html, css e js.

## Pagina feita usando metodologia BEM (Block Element Modifier)
## HTML, CSS, JS
